# Namrata Yadav — Portfolio

Live at https://namratavlsi.github.io

Every file sits at the top level of this repository — no folders. To add an image, upload it
here with the exact filename below and it appears on the site automatically.

## Images to add

Upload these to the repository root. Landscape crops, roughly 16:9, at least 1200 px wide.
Crop out tool licence banners, usernames, and file paths before uploading.

| Project | Recommended image | Filename |
| --- | --- | --- |
| — | Your photo, square crop | `profile.jpg` |
| — | Your résumé | `Namrata_Yadav_Resume.pdf` |
| LIF neuron | Neuron layout (home page card) | `lif_neuron_layout.png` |
| LIF neuron | Transistor-level schematic | `lif_neuron_schematic.png` |
| LIF neuron | Vmem + spike transient waveform | `lif_spike_waveform.png` |
| LIF neuron | F–I response curve | `lif_fi_response.png` |
| Analog IC | OTA layout (home page card) | `analog_ota_layout.png` |
| Analog IC | Two-stage op-amp schematic | `analog_opamp_schematic.png` |
| Analog IC | DRC/LVS clean summary | `analog_drc_lvs_clean.png` |
| Analog IC → LDO | Full hierarchical layout (home page card) | `ldo_layout.png` |
| Analog IC → LDO | Schematic | `ldo_schematic.png` |
| Analog IC → LDO | Transient response | `ldo_transient.png` |
| Analog IC → LDO | PSRR vs. frequency | `ldo_psrr_plot.png` |
| Analog IC → LDO | Loop gain / phase | `ldo_loop_stability.png` |
| Analog IC → Bandgap | 5 × 5 common-centroid BJT array | `bandgap_common_centroid_layout.png` |
| Analog IC → Bandgap | Schematic | `bandgap_schematic.png` |
| Mixed-signal | Top-level PLL schematic | `pll_top_level.png` |
| Mixed-signal | PLL layout | `pll_layout.png` |
| Mixed-signal | Serializer / deserializer schematic or layout | `serdes_block.png` |
| Digital custom | Standard-cell library layout | `standard_cell_library.png` |
| Digital custom | Hierarchical block layout | `digital_hierarchical_layout.png` |
| Digital custom | Pre-/post-layout comparison | `digital_pex_postlayout.png` |
| Digital custom → SRAM | 6T array layout | `sram_6t_array.png` |
| Digital custom → SRAM | 6T bitcell schematic | `sram_6t_schematic.png` |
| ALU | ICC2 floorplan | `alu_floorplan.png` |
| ALU | Post-route layout | `alu_routed.png` |
| ALU | PrimeTime timing report | `alu_timing_report.png` |
| Temperature sensor | Temperature sweep graph | `temperature_sensor_sweep.png` |
| Temperature sensor | Schematic | `tempsensor_schematic.png` |
| Temperature sensor | VTH / gm / ID trends | `tempsensor_vth_gm_id.png` |
| Temperature sensor | Monte Carlo distribution | `tempsensor_monte_carlo.png` |
| Temperature sensor | Aging analysis | `tempsensor_aging.png` |
| NN video processing | Architecture diagram | `nn_video_architecture.png` |
| NN video processing | System-level layout | `nn_video_layout.png` |

## Pages

`index.html` home · `experience.html` · `projects.html` · `contact.html`, plus one page per
project: `lif-neuron.html`, `analog-ic.html`, `mixed-signal.html`, `digital-custom.html`,
`physical-design-alu.html`, `temperature-sensor.html`, `neural-network-video-processing.html`.

`ldo.html`, `bandgap.html`, and `sram.html` are redirect stubs — that work now lives inside
`analog-ic.html` and `digital-custom.html`, and the stubs keep any old link working.

## Editing

Text lives directly in the HTML — open the file on GitHub, click the pencil icon, edit, commit.
To change the accent colour, edit `--accent` near the top of `styles.css`.
